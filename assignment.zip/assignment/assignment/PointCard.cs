﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment
{
    class PointCard
    {
        public int Points { get; set; }
        public int PunchCard {  get; set; }
        public string Tier { get; set; }

        public PointCard() { }
        public  PointCard(int points, int punchCard) 
        {
            Points = points;
            PunchCard = punchCard;
        }

        public void AddPoint(int amt) 
        {
            int addpoints = Convert.ToInt32(Math.Floor(amt * 0.72));
            Points += addpoints;
        }

        
    }
}
