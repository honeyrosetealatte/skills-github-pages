﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment
{
    class Waffle : IceCream
    {
        public string WaffleFlavour { get; set; }
        public Waffle() { }

        public Waffle(string option, int scoops, List<Flavour> flavours, List<Topping> toppings, string waffleFlavour) : base(option, scoops, flavours, toppings)
        {
            WaffleFlavour = waffleFlavour;
        }

        public override double CalculatePrice()
        {
            double price = 0;
            if (Scoops == 1)
            {
                price = 7;
            }
            else if (Scoops == 2)
            {
                price = 8.5;
            }
            else if (Scoops == 3)
            {
                price = 9.5;
            }
            foreach (Flavour flavour in Flavours)
            {
                if (flavour.Premium == true)
                {
                    price += 2;
                }
            }
            foreach (Topping topping in Toppings)
            {
                price += 1;
            }

            if (WaffleFlavour != null)
            {
                price += 3;
            }

            return price;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
