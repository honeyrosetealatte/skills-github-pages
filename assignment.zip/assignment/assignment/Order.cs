﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment
{
    class Order
    {
        public int Id { get; set; }
        public DateTime TimeReceived { get; set; }
        public DateTime? TimeFulfilled { get; set; }
        public List<IceCream> iceCreamList { get; set; } = new List<IceCream>();

        public Order() { }
        public Order(int id, DateTime timeReceived)
        {
            Id = id;
            TimeReceived = timeReceived;
        }

        public void ModifyIceCream(int id)
        {
            List<Flavour> newflavours = new List<Flavour>();

            Console.Write("Enter option(cone/cup/waffle): ");
            string option = Console.ReadLine().ToLower();

            Console.Write("Enter number of scoops: ");
            int scoops = Convert.ToInt32(Console.ReadLine());
            if (scoops == 1)
            {
                Console.Write("Enter flavour of scoop 1: ");
                string flavour1 = Console.ReadLine();
                //newflavours.Add(flavour1);
            }

            else if (scoops == 2) 
            {
                Console.Write("Enter flavour of scoop 1: ");
                string flavour1 = Console.ReadLine();
                Console.Write("Enter flavour of scoop 2: ");
                string flavour2 = Console.ReadLine();
            }

            else if (scoops == 3)
            {
                Console.Write("Enter flavour of scoop 1: ");
                string flavour1 = Console.ReadLine();
                Console.Write("Enter flavour of scoop 2: ");
                string flavour2 = Console.ReadLine();
                Console.Write("Enter flavour of scoop 3: ");
                string flavour3 = Console.ReadLine();
            }







            if (option == "cup")
            {
                
            }
        }
    }
}
